-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2022 at 04:41 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zenius-flight`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

CREATE TABLE `flights` (
  `id` int(10) NOT NULL,
  `plane_id` int(10) DEFAULT NULL,
  `flight_gates_id` int(10) DEFAULT NULL,
  `flight_class_id` int(10) DEFAULT NULL,
  `flight_number` varchar(15) DEFAULT NULL,
  `arrival` varchar(25) DEFAULT NULL,
  `departure` varchar(25) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  `price` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`id`, `plane_id`, `flight_gates_id`, `flight_class_id`, `flight_number`, `arrival`, `departure`, `date`, `time`, `price`) VALUES
(1, 1, 1, 4, '547', 'Jakarta', 'Singapore', '2022-07-28', '09:20:00', ''),
(2, 2, 2, 3, '315', 'Jakarta', 'Bali', '2022-07-28', '09:20:00', ''),
(3, 3, 1, 1, '366', 'Jakarta', 'Solo', '2022-07-28', '09:20:00', ''),
(4, 4, 2, 2, '326', 'Jakarta', 'Surabaya', '2022-07-28', '09:20:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `flight_classes`
--

CREATE TABLE `flight_classes` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flight_classes`
--

INSERT INTO `flight_classes` (`id`, `name`) VALUES
(1, 'Economy'),
(2, 'Business'),
(3, 'Premium Economy'),
(4, 'First Class');

-- --------------------------------------------------------

--
-- Table structure for table `flight_gates`
--

CREATE TABLE `flight_gates` (
  `id` int(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flight_gates`
--

INSERT INTO `flight_gates` (`id`, `name`, `status`) VALUES
(1, 'GATE 1', 'OPEN'),
(2, 'GATE 2', 'CLOSE');

-- --------------------------------------------------------

--
-- Table structure for table `planes`
--

CREATE TABLE `planes` (
  `id` int(10) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `capacity` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `planes`
--

INSERT INTO `planes` (`id`, `code`, `type`, `capacity`) VALUES
(1, 'A320', 'Boeing 737', 40),
(2, 'A550', 'Boeing 737', 30),
(3, 'A530', 'Boeing 747', 30),
(4, 'B120', 'Airbus A33', 40);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`) VALUES
(1, 'Attiqi', 'attiqi@gmail.com', '085985928'),
(2, 'koko', 'kokok@gmail.com', '0819283723'),
(3, 'iko', 'iko@gmail.com', '90192832'),
(4, 'rose', 'rose@gmail.com', '081928372');

-- --------------------------------------------------------

--
-- Table structure for table `user_flights`
--

CREATE TABLE `user_flights` (
  `id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `flight_id` int(10) DEFAULT NULL,
  `seat_number` varchar(5) DEFAULT NULL,
  `ticket_number` varchar(100) DEFAULT NULL,
  `user_flight_code` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_flights`
--

INSERT INTO `user_flights` (`id`, `user_id`, `flight_id`, `seat_number`, `ticket_number`, `user_flight_code`) VALUES
(1, 1, 1, '31A', '019264019245655', '152A4F2F');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flights`
--
ALTER TABLE `flights`
  ADD PRIMARY KEY (`id`),
  ADD KEY `plane_id` (`plane_id`),
  ADD KEY `flight_gates_id` (`flight_gates_id`),
  ADD KEY `flight_class_id` (`flight_class_id`);

--
-- Indexes for table `flight_classes`
--
ALTER TABLE `flight_classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flight_gates`
--
ALTER TABLE `flight_gates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `planes`
--
ALTER TABLE `planes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_flights`
--
ALTER TABLE `user_flights`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `flight_id` (`flight_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `flights`
--
ALTER TABLE `flights`
  ADD CONSTRAINT `flights_ibfk_1` FOREIGN KEY (`flight_class_id`) REFERENCES `flight_classes` (`id`),
  ADD CONSTRAINT `flights_ibfk_2` FOREIGN KEY (`plane_id`) REFERENCES `planes` (`id`),
  ADD CONSTRAINT `flights_ibfk_3` FOREIGN KEY (`flight_gates_id`) REFERENCES `flight_gates` (`id`);

--
-- Constraints for table `user_flights`
--
ALTER TABLE `user_flights`
  ADD CONSTRAINT `user_flights_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `user_flights_ibfk_2` FOREIGN KEY (`flight_id`) REFERENCES `flights` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
